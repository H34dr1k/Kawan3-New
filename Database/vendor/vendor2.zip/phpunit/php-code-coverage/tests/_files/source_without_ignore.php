<?php
if ($neverHappens) {
    print '*';
}
