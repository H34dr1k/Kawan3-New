<?php
function globalFunction()
{
}
